﻿//************************************** Welcome to Card Game *************************************************//

//--------------------------------------- Execution WorkFlow --------------------------------------------------//

1. Program.cs -> GamePlayController(Initializing Players) -> calls -> (create cards) method of DeckCreatorController 
-> Control goes back to -> Program.cs and call PlayGame method of GamePlayController and also eventually calling mehtod of endOfGame(condition) 
of GamePlayController.

//--------------------------------------- Data Structure and Functions-----------------------------------------//
We are using "Queue"" data structure, "Linq" queries, "Random function", "List" data structure.

//--------------------------------------- Hierarchy -----------------------------------------------------------//
We have three folders-> Controllers, Interfaces, Models and one Enum Class.

//--------------------------------------- Controllers ---------------------------------------------------------//  
     2.1 DeckCreatorController : Static class, having three static methods (CreateCards, Shuffle, GetShortName), purpose is to create cards accordings to suits (defined in Enum class) and shuffle the cards.
                                  Returns 52 set of cards randomly (shuffled).
                                  
     2.2 DisplayController : Static class, having three static methods (DisplayUserCards, DisplayComputerCards, Score), purpose is to display left overs cards for both users (our user and computer user).
                              Showing exact card names according to display request and also show the current score for each user.

     2.3 GamePlayController : Normal class, containing actual business logic.
            2.31 Having contructor (GamePlayController), which is actually initializing the players and divide cards to each user (26 each).
            2.32 Containg one method PlayGame -> invoked from main method based on one conditional function i.e, IsEndOfGame.
                 In this method, we getting input from computer(card) and after that, providing our input(card) and functionality
                 check which card value is higher and eventualy adds the card to the user who wins and remove that card from user who lost.
            2.33 We also added/incorporated "TIE" condition -> according to our logic, if both card value is same, we added while loop till this conditon satisfies,
                 We are removing 3 cards from both users, and then again they have to put fourth card to check  condition, if again match, then again while loop otherwise normal logic.
            2.34 We added one method IsEndOfGame, if any of the player is out of cards, we are stopping the game.

//----------------------------------------- Interfaces ----------------------------------------------------------//
Only one interface is required, IGamePlay, because other classes are static.

//------------------------------------------ Models -------------------------------------------------------------//
   4.1 Card class -> Having three properties (DisplayName, Suit, Value).
   4.2 Player class -> Having three properties (Name, Deck, Score).

//------------------------------------------- Execution ---------------------------------------------------------//
Directly start the application from the top, then first we are allowing computer to choose card(automatic/ random function), then we requesting user to 
to choose cards from remaining set, same for computer as well.
We can continue the game until we want just hit enter to proceed, game is on till any of user loses all his cards.

//************************* This code is perfectly running for all cases mentioned above ******************************//


6. Suggestion : We can redefine logic for "TIE" Case and we can add more fail safe conditions.
                
