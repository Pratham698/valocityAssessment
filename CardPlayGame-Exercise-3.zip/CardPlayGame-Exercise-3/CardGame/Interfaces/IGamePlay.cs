﻿using CardGame.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame.Interfaces
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public interface IGamePlay
    {
        void PlayGame();
        bool IsEndOfGame();
    }
}
