﻿using CardGame.Objects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CardGame.Controllers
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public static class DeckCreatorController
    {
        //----------------------------- Creating Cards --------------------------------------------------//
        public static Queue<Card> CreateCards()
        {
            Queue<Card> cards = new Queue<Card>();
            for (int i = 2; i <= 14; i++)
            {
                foreach (Suit suit in Enum.GetValues(typeof(Suit)))
                {
                    cards.Enqueue(new Card()
                    {
                        Suit = suit,
                        Value = i,
                        DisplayName = GetShortName(i, suit)
                    });
                }
            }
            return Shuffle(cards);
        }


        //------------------------------ Shuffle Logic ------------------------------------------------//
        private static Queue<Card> Shuffle(Queue<Card> cards)
        {
            List<Card> transformedCards = cards.ToList();
            Random rand = new Random();

            for (int i = 0; i < transformedCards.Count(); i++)
            {
                int k = i + rand.Next(52 - i);

                Card temp = transformedCards[i];
                transformedCards[i] = transformedCards[k];
                transformedCards[k] = temp;
            }

            Queue<Card> shuffledCards = new Queue<Card>();
            foreach (var card in transformedCards)
            {
                shuffledCards.Enqueue(card);
            }

            //Checking whether duplicates cards enqueued, we are removing them, and finally returing successfully
            //shuffled card set.
            Queue<Card> finalShuffledCards = new Queue<Card>(shuffledCards.Distinct());
            return finalShuffledCards;
        }


        //-------------------------------------- Display -----------------------------------------------//
        private static string GetShortName(int value, Suit suit)
        {
            string valueDisplay = "";
            if (value >= 2 && value <= 10)
            {
                valueDisplay = value.ToString();
            }
            else if (value == 11)
            {
                valueDisplay = "J";
            }
            else if (value == 12)
            {
                valueDisplay = "Q";
            }
            else if (value == 13)
            {
                valueDisplay = "K";
            }
            else if (value == 14)
            {
                valueDisplay = "A";
            }

            return valueDisplay + Enum.GetName(typeof(Suit), suit)[0];
        }
    }
}
