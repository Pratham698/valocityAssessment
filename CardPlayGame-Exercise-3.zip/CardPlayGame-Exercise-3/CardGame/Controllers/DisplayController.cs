﻿using CardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame.Controllers
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public static class DisplayController
    {
        public static void DisplayUserCards(Player player1)
        {
            Console.WriteLine("User remaining Cards : ");
            foreach (var card in player1.Deck)
            {
                Console.Write(card.DisplayName + " ");
            }
            Console.WriteLine();
        }

        public static void DisplayComputerCards(Player player2)
        {
            Console.WriteLine("Computer remaining Cards : ");
            foreach (var card in player2.Deck)
            {
                Console.Write(card.DisplayName + " ");
            }
            Console.WriteLine();
        }

        public static void Score(int scoreComp, int scoreUser)
        {
            Console.WriteLine("Computer Score till now : " + scoreComp + '\n' + "User score till now : " + scoreUser);
        }
    }
}
