﻿using CardGame.Interfaces;
using CardGame.Models;
using CardGame.Objects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CardGame.Controllers
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public class GamePlayController : IGamePlay
    {
        //User
        private Player player1;

        //Computer/machine
        private Player player2;

        public GamePlayController(string player1name, string player2name)
        {
            player1 = new Player(player1name);
            player2 = new Player(player2name);

            //Creating Cards, it returns shuffled cards.
            var cards = DeckCreatorController.CreateCards();

            //Diving Cards between players.
            Queue<Card> player1cards = new Queue<Card>();
            Queue<Card> player2cards = new Queue<Card>();

            int counter = 2;
            while (cards.Any())
            {
                if (counter % 2 == 0)
                {
                    player2cards.Enqueue(cards.Dequeue());
                }
                else
                {
                    player1cards.Enqueue(cards.Dequeue());
                }
                counter++;
            }

            //both players (user and computer have 26 cards each, after shuffled)
            player1.Deck = player1cards;
            player2.Deck = player2cards;
        }

        public void PlayGame()
        {
            //******************************** Computer Turn ******************************************//
            Console.WriteLine("Computer Turn : Choose any card from given below");
            DisplayController.DisplayComputerCards(player2);

            var random = new Random();
            var player2CardNames = player2.Deck.Select(s => s.DisplayName).ToList();
            int index = random.Next(player2CardNames.Count);
            var deskCard = player2CardNames[index];
            Console.Write("Entered Card by Computer : " + deskCard);
            Console.WriteLine();
            Queue<Card> remainingCardsAfterPicked = new Queue<Card>(player2.Deck.Where(card => card.DisplayName != deskCard));
            Card player2card = player2.Deck.Where(card => card.DisplayName == deskCard).FirstOrDefault();
            player2.Deck = remainingCardsAfterPicked;


            //******************************** User Turn **********************************************//
            Console.WriteLine("User Turn : Choose any card from given below");
            DisplayController.DisplayUserCards(player1);
            Card player1card = new Card();

            //Handling Exception and providing Retry mechanism, until user picks correct card from given set.
            while (true)
            {
                Console.Write("Enter your card : ");
                deskCard = Console.ReadLine();
                var check = player1.Deck.Select(s => s.DisplayName).ToList();
                if (check.Contains(deskCard))
                {
                    remainingCardsAfterPicked = new Queue<Card>(player1.Deck.Where(card => card.DisplayName != deskCard));
                    player1card = player1.Deck.Where(card => card.DisplayName == deskCard).FirstOrDefault();
                    player1.Deck = remainingCardsAfterPicked;
                    break;
                }
                else
                {
                    Console.WriteLine("Please pick from given set only...");
                }
            }

            //********************* Displaying whatever both user played/ put cards ******************//
            Console.WriteLine();
            Console.WriteLine(player2.Name + " plays " + player2card.DisplayName + ", " + player1.Name + " plays " + player1card.DisplayName);

            if (player1card.Value > player2card.Value)
            {
                player1.Deck.Enqueue(player2card);
                player1.Deck.Enqueue(player1card);
                Console.WriteLine(player1.Name + " takes the hand - Nice Played!");
                player1.Score++;
            }
            else if (player2card.Value > player1card.Value)
            {
                player2.Deck.Enqueue(player1card);
                player2.Deck.Enqueue(player2card);
                Console.WriteLine(player2.Name + " takes the hand - Nice Played!");
                player2.Score++;
            }

            /*Tie Logic, if both cards are same, then both users have to give penality they need to put their three cards
             * in a seqential form, then again they have to put fourth card to proceed, then again same logic we are appling 
             * for card comparison, if again same, then again penality will applies to them otherwise normal comparison.
            */
            else
            {
                while (player1card.Value == player2card.Value)
                {
                    Console.WriteLine("It'a a War!");
                    if (player1.Deck.Count < 4)
                    {
                        player1.Deck.Clear();
                        return;
                    }
                    if (player2.Deck.Count < 4)
                    {
                        player2.Deck.Clear();
                        return;
                    }

                    player1.Deck.Dequeue();
                    player1.Deck.Dequeue();
                    player1.Deck.Dequeue();
                    player2.Deck.Dequeue();
                    player2.Deck.Dequeue();
                    player2.Deck.Dequeue();

                    player1card = player1.Deck.Dequeue();
                    player2card = player2.Deck.Dequeue();

                    if (player1card.Value > player2card.Value)
                    {
                        player1.Deck.Enqueue(player2card);
                        player1.Deck.Enqueue(player1card);
                        Console.WriteLine(player1.Name + " takes the hand - Nice Played!");
                        player1.Score++;
                    }

                    if (player2card.Value > player1card.Value)
                    {
                        player2.Deck.Enqueue(player1card);
                        player2.Deck.Enqueue(player2card);
                        Console.WriteLine(player2.Name + " takes the hand - Nice Played!");
                        player2.Score++;
                    }
                }
            }
            DisplayController.Score(player2.Score, player1.Score);
            Console.WriteLine("Play another round, hit enter...");
            Console.ReadLine();
        }

        //********************************* Checking Game Termination Condition ********************************//
        public bool IsEndOfGame()
        {
            if (!player1.Deck.Any())
            {
                Console.WriteLine(player1.Name + " is out of cards!  " + player2.Name + " WINS!");
                return true;
            }
            else if (!player2.Deck.Any())
            {
                Console.WriteLine(player2.Name + " is out of cards!  " + player1.Name + " WINS!");
                return true;
            }
            return false;
        }
    }
}
