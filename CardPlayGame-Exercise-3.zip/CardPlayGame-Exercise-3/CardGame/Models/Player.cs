﻿using CardGame.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame.Models
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public class Player
    {
        public string Name { get; set; }
        public Queue<Card> Deck { get; set; }
        public int Score { get; set; }

        public Player() { }

        public Player(string name)
        {
            Name = name;
        }
    }
}
