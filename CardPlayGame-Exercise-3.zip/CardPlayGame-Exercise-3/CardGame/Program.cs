﻿using CardGame.Controllers;
using System;

namespace CardGame
{
    //Please Refer to ReadMe.md file to know the whole flow.
    public class Program
    {
        static void Main(string[] args)
        {
            //Creating two users, first is user, second one is our CPU/machine 
            GamePlayController game = new GamePlayController("Alice - User", "Bob - Computer");

            while(!game.IsEndOfGame())
            {
                game.PlayGame();
            }
            Console.ReadLine();
        }
    }
}
