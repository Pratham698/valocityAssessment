﻿CodeToRefactor Changes:

I have added comments in CodeToRefactor file, on above of each methods as well.


1.      This one is static readonly field, we can initialize compile time, but if we need to chnage this value 
        during run time, we need to create one static constructor to do this, after one time change, this value cannot change further.
        Also we cannot manipulate this field inside non staic constructor
        Example :

        static People()
        {
            Under16 = DateTimeOffset.UtcNow.AddYears(-20);
        }
        
2.       We do not need 2 contructors, which leads to same result only.
         Once this below contructor invoked during object creation, it will automatically call next contructor only,
         instead we can keep only second contructor to serve our purpose.
         Example - we can remove this contructor: 
         public People(string name) : this(name, Under16.Date)
            {

            }

         We need only this contructor. 
         public People(string name, DateTime dob)
            {
                Name = name;
                DOB = dob;
            }

3.       All Public method should be written first, then private methods for clean code writing.
         Other reason, it is quicker to find all public methods at first, because we will know whom all methods test cases we have write.
         For private methods, we cannot write test cases.
  
         
4.       In this function we are creating people, only two users we have, we can create 'n' number of users with same name but different ages.
         Also we are adding into people object(list of people) and return all user we have created so far.z



*************************************************Suggestions**********************************************************

1. We have to segregate the classes People & BirthingUnit to follow Single Responsibility principle(Solid).
2. In catch Block line: [96 - 100] ------->

We need to create most specfic Exception code first then generic one, like we have written in code, this is wrong way.
catch block should follow the hierarchy [most specific -> most generic]

3. All Public method should be written first, then private methods should be written, for clean code writing.