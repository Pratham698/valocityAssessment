﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CodingAssessment.Refactor
{
    public class People
    {
        /*This one is static readonly field, we can initialize compile time, but if we need to chnage this value 
        during run time, we need to create one static constructor to do this, after one time change, this value cannot change further.
        Also we cannot manipulate this field inside non staic constructor
        Example :

        static People()
        {
            Under16 = DateTimeOffset.UtcNow.AddYears(-20);
        }
        */

        private static readonly DateTimeOffset Under16 = DateTimeOffset.UtcNow.AddYears(-15);
        public string Name { get; private set; }
        public DateTimeOffset DOB { get; private set; }

        /*.We do not need 2 contructors, which leads to same result only.
         * Once this below contructor invoked during object creation, it will automatically call next contructor only,
         * instead we can keep only second contructor to serve our purpose.
         * Example - we can remove this contructor: 
         * public People(string name) : this(name, Under16.Date)
            {

            }

         * We need only this contructor. 
         * public People(string name, DateTime dob)
            {
                Name = name;
                DOB = dob;
            }
        */
        public People(string name) : this(name, Under16.Date)
        {
        }

        public People(string name, DateTime dob)
        {
            Name = name;
            DOB = dob;
        }
    }

    public class BirthingUnit
    {
        /* All Public method should be written first, then private methods for clean code writing.
         * Other reason, it is quicker to find all public methods at first, because we will know whom all methods test cases we have write.
         * For private methods, we cannot write test cases.
        */

        /// <summary>
        /// MaxItemsToRetrieve
        /// </summary>
        private List<People> _people;

        public BirthingUnit()
        {
            _people = new List<People>();
        }

        /* In this function we are creating people, only two users we have, we can create 'n' number of users with same name but different ages.
         * Also we are adding into people object(list of people) and return all user we have created so far.
         */

        /// <summary>
        /// GetPeoples
        /// </summary>
        /// <param name="j"></param>
        /// <returns>List<object></returns>
        public List<People> GetPeople(int i)
        {
            for (int j = 0; j < i; j++)
            {
                try
                {
                    // Creates a dandon Name
                    string name = string.Empty;
                    var random = new Random();
                    if (random.Next(0, 1) == 0) {
                        name = "Bob";
                    }
                    else {
                        name = "Betty";
                    }
                    // Adds new people to the list
                    _people.Add(new People(name, DateTime.UtcNow.Subtract(new TimeSpan(random.Next(18, 85) * 356, 0, 0, 0))));
                }
                catch (Exception e)
                {
                    // Dont think this should ever happen
                    throw new Exception("Something failed in user creation");
                }
            }
            return _people;
        }


        /* This method return all user which is having name Bob and age olderThan30 */
        private IEnumerable<People> GetBobs(bool olderThan30)
        {
            return olderThan30 ? _people.Where(x => x.Name == "Bob" && x.DOB >= DateTime.Now.Subtract(new TimeSpan(30 * 356, 0, 0, 0))) : _people.Where(x => x.Name == "Bob");
        }

        /* Returning married users */
        public string GetMarried(People p, string lastName)
        {
            if (lastName.Contains("test"))
                return p.Name;
            if ((p.Name.Length + lastName).Length > 255)
            {
                (p.Name + " " + lastName).Substring(0, 255);
            }

            return p.Name + " " + lastName;
        }
    }
}