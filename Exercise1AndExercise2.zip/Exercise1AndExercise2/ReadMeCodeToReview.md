CodeToReview Changes:

I have added comments in CodeToRefactor file as well.

1. We have to segregate the classes People & BirthingUnit to follow Single Responsibility principle(Solid),
each class should have only reason to change/ should contain only related information.

2. All methods should be placed in controller class, so that we can easily provide the access to other modules, visibility perspective.
GetPeople, GetBobs, GetMarried.

3. Randon function, which is in line 43, need to move to line 36, we only going to create Random function, once we hit the methods, 
rather creating again & again inside the loop.
